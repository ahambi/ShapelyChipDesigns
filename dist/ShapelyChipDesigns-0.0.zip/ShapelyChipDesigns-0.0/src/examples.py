
def run_examples():
    """
    EBL markers
     
    .. plot:: examples/example_EBL_markers.py
       :include-source:    
    
    """